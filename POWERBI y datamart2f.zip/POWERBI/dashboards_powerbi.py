import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from matplotlib.patches import Rectangle
import warnings
warnings.filterwarnings('ignore')

# Configuración estilo Power BI
plt.rcParams['figure.facecolor'] = '#F8F9FA'
plt.rcParams['axes.facecolor'] = '#FFFFFF'
sns.set_palette(['#005A9B', '#44AA99', '#999933', '#AA4499', '#882255', '#CC6677'])

def crear_datos_desde_texto():
    """
    Recrea los datasets desde la información proporcionada
    """
    
    # Datos de Cartera
    data_cartera = {
        'CARTERA': ['COMÚN', 'COMÚN', 'COMÚN', 'MAYOR', 'MAYOR', 'MAYOR'],
        'DEPARTAMENTO': ['Ancash', 'Cajamarca', 'La Libertad', 'Ancash', 'Cajamarca', 'La Libertad'],
        'Consumo_Total_sum': [24341313, 9976909, 47637892, 10501097, 2079784, 18736106],
        'Consumo_Total_mean': [81.99, 64.86, 96.74, 8982.97, 6099.07, 11724.72],
        'Consumo_Total_count': [296885, 153826, 492416, 1169, 341, 1598],
        'ID_CLIENTE_nunique': [296885, 153826, 492416, 1169, 341, 1598]
    }
    
    # Datos de Distribución
    data_distribucion = {
        'Rango_Consumo': ['101-500', '51-100', '0-10', '26-50', '11-25', '500+'],
        'count': [212370, 199459, 150827, 141432, 121354, 19060]
    }
    
    # Datos Temporales
    data_temporal = {
        'AÑO': [2022, 2022, 2022, 2022, 2022, 2022],
        'MES': [9, 9, 9, 10, 10, 10],
        'DEPARTAMENTO': ['Ancash', 'Cajamarca', 'La Libertad', 'Ancash', 'Cajamarca', 'La Libertad'],
        'Consumo_Total': [23282888, 9976819, 44918986, 11559522, 2079874, 21455012],
        'Consumo_Promedio': [82.09, 64.86, 96.07, 801.85, 6081.5, 811.64],
        'ID_CLIENTE': [283638, 153825, 467580, 14416, 342, 26434]
    }
    
    # Datos por Departamento (muestra de los principales)
    data_departamento = {
        'DEPARTAMENTO': ['Ancash', 'Cajamarca', 'La Libertad'],
        'Consumo_Total_sum': [34842410, 12056693, 66373998],
        'Consumo_Total_mean': [34.95, 78.3, 71.59],
        'Consumo_Total_count': [298054, 154167, 494014],
        'ID_CLIENTE_nunique': [298054, 154167, 494014]
    }
    
    # Top Consumidores (primeros 10 del dataset proporcionado)
    data_top = {
        'ID_CLIENTE': [313664, 342873, 874208, 754579, 936951, 766165, 804158, 395783, 924431, 664103],
        'Consumo_Total': [1361824, 399695, 370549, 361259, 359218, 302770, 302155, 278948, 259330, 225024],
        'DEPARTAMENTO': ['La Libertad', 'Ancash', 'La Libertad', 'La Libertad', 'Ancash', 
                        'Ancash', 'La Libertad', 'Ancash', 'Ancash', 'Ancash'],
        'CARTERA': ['MAYOR'] * 10
    }
    
    return (pd.DataFrame(data_cartera), pd.DataFrame(data_distribucion), 
            pd.DataFrame(data_temporal), pd.DataFrame(data_departamento),
            pd.DataFrame(data_top))

def crear_dashboard_corporativo(df_cartera, df_departamento, df_distribucion):
    """
    Dashboard Nivel 1: Vista Corporativa (siguiendo metodología Inmon Top-Down)
    """
    fig = plt.figure(figsize=(20, 12))
    fig.suptitle('🏢 DASHBOARD CORPORATIVO - CONSUMO DE SERVICIOS\n(Metodología Bill Inmon - Vista Top-Down)', 
                 fontsize=18, fontweight='bold', y=0.95)
    
    # Panel 1: Consumo por Departamento (Mapa de Calor)
    ax1 = plt.subplot(2, 3, 1)
    consumo_pivot = df_cartera.pivot_table(values='Consumo_Total_sum', 
                                         index='DEPARTAMENTO', 
                                         columns='CARTERA', 
                                         aggfunc='sum')
    
    sns.heatmap(consumo_pivot, annot=True, fmt='.0f', cmap='Blues', ax=ax1, 
                cbar_kws={'label': 'Consumo Total'})
    ax1.set_title('📊 Consumo por Departamento y Cartera\n(Data Warehouse Corporativo)', 
                  fontweight='bold', pad=20)
    ax1.set_xlabel('Tipo de Cartera', fontweight='bold')
    ax1.set_ylabel('Departamento', fontweight='bold')
    
    # Panel 2: Distribución de Consumidores
    ax2 = plt.subplot(2, 3, 2)
    colors = ['#005A9B', '#44AA99', '#999933', '#AA4499', '#882255', '#CC6677']
    wedges, texts, autotexts = ax2.pie(df_distribucion['count'], 
                                       labels=df_distribucion['Rango_Consumo'],
                                       autopct='%1.1f%%', 
                                       colors=colors,
                                       explode=[0.1 if x == df_distribucion['count'].max() else 0 
                                               for x in df_distribucion['count']])
    
    ax2.set_title('🎯 Distribución de Consumidores por Rango\n(Segmentación Estratégica)', 
                  fontweight='bold', pad=20)
    
    # Panel 3: Totales por Departamento
    ax3 = plt.subplot(2, 3, 3)
    dept_totals = df_departamento.sort_values('Consumo_Total_sum', ascending=True)
    bars = ax3.barh(dept_totals['DEPARTAMENTO'], dept_totals['Consumo_Total_sum']/1000000)
    ax3.set_title('📈 Consumo Total por Departamento\n(Millones)', fontweight='bold', pad=20)
    ax3.set_xlabel('Consumo (Millones)', fontweight='bold')
    
    # Agregar valores en las barras
    for i, bar in enumerate(bars):
        width = bar.get_width()
        ax3.text(width + 1, bar.get_y() + bar.get_height()/2, 
                f'{width:.1f}M', ha='left', va='center', fontweight='bold')
    
    # Panel 4: Análisis por Cartera
    ax4 = plt.subplot(2, 3, 4)
    cartera_analysis = df_cartera.groupby('CARTERA').agg({
        'Consumo_Total_sum': 'sum',
        'Consumo_Total_count': 'sum'
    })
    
    x = np.arange(len(cartera_analysis))
    width = 0.35
    
    bars1 = ax4.bar(x - width/2, cartera_analysis['Consumo_Total_sum']/1000000, 
                    width, label='Consumo Total (Millones)', color='#005A9B')
    bars2 = ax4.bar(x + width/2, cartera_analysis['Consumo_Total_count']/1000, 
                    width, label='N° Clientes (Miles)', color='#44AA99')
    
    ax4.set_title('💼 Análisis por Tipo de Cartera\n(Vista Estratégica)', fontweight='bold', pad=20)
    ax4.set_xlabel('Tipo de Cartera', fontweight='bold')
    ax4.set_xticks(x)
    ax4.set_xticklabels(cartera_analysis.index)
    ax4.legend()
    ax4.grid(True, alpha=0.3)
    
    # Panel 5: KPIs Principales
    ax5 = plt.subplot(2, 3, 5)
    ax5.axis('off')
    
    # Calcular KPIs
    total_consumo = df_departamento['Consumo_Total_sum'].sum()
    total_clientes = df_departamento['ID_CLIENTE_nunique'].sum()
    promedio_consumo = df_departamento['Consumo_Total_mean'].mean()
    
    kpis = [
        ('Consumo Total', f'{total_consumo/1000000:.1f}M', '#005A9B'),
        ('Total Clientes', f'{total_clientes/1000:.0f}K', '#44AA99'),
        ('Promedio Consumo', f'{promedio_consumo:.1f}', '#999933')
    ]
    
    y_positions = [0.8, 0.5, 0.2]
    
    for i, (label, value, color) in enumerate(kpis):
        # Crear rectángulo de fondo
        rect = Rectangle((0.1, y_positions[i]-0.08), 0.8, 0.16, 
                        facecolor=color, alpha=0.2)
        ax5.add_patch(rect)
        
        # Agregar texto
        ax5.text(0.5, y_positions[i]+0.02, value, 
                ha='center', va='center', fontsize=20, fontweight='bold', color=color)
        ax5.text(0.5, y_positions[i]-0.04, label, 
                ha='center', va='center', fontsize=12, fontweight='bold')
    
    ax5.set_xlim(0, 1)
    ax5.set_ylim(0, 1)
    ax5.set_title('📊 KPIs Corporativos\n(Indicadores Clave)', fontweight='bold', pad=20)
    
    # Panel 6: Eficiencia por Departamento
    ax6 = plt.subplot(2, 3, 6)
    dept_efficiency = df_departamento.copy()
    dept_efficiency['Eficiencia'] = (dept_efficiency['Consumo_Total_sum'] / 
                                   dept_efficiency['ID_CLIENTE_nunique'])
    
    scatter = ax6.scatter(dept_efficiency['ID_CLIENTE_nunique'], 
                         dept_efficiency['Consumo_Total_sum'],
                         s=dept_efficiency['Eficiencia']/50, 
                         c=dept_efficiency['Consumo_Total_mean'],
                         cmap='viridis', alpha=0.7)
    
    for i, dept in enumerate(dept_efficiency['DEPARTAMENTO']):
        ax6.annotate(dept, 
                    (dept_efficiency['ID_CLIENTE_nunique'].iloc[i], 
                     dept_efficiency['Consumo_Total_sum'].iloc[i]),
                    xytext=(5, 5), textcoords='offset points', fontweight='bold')
    
    ax6.set_title('🎯 Matriz de Eficiencia\n(Clientes vs Consumo)', fontweight='bold', pad=20)
    ax6.set_xlabel('Número de Clientes', fontweight='bold')
    ax6.set_ylabel('Consumo Total', fontweight='bold')
    ax6.grid(True, alpha=0.3)
    
    plt.colorbar(scatter, ax=ax6, label='Consumo Promedio')
    
    plt.tight_layout()
    return fig

def crear_dashboard_temporal(df_temporal):
    """
    Dashboard Nivel 2: Análisis Temporal (Data Mart Temporal)
    """
    fig = plt.figure(figsize=(16, 10))
    fig.suptitle('📅 DASHBOARD TEMPORAL - ANÁLISIS DE TENDENCIAS\n(Data Mart Especializado - Metodología Inmon)', 
                 fontsize=16, fontweight='bold', y=0.95)
    
    # Panel 1: Evolución Temporal por Departamento
    ax1 = plt.subplot(2, 2, 1)
    
    for dept in df_temporal['DEPARTAMENTO'].unique():
        data_dept = df_temporal[df_temporal['DEPARTAMENTO'] == dept]
        ax1.plot(data_dept['MES'], data_dept['Consumo_Total']/1000000, 
                marker='o', linewidth=3, markersize=8, label=dept)
    
    ax1.set_title('📈 Evolución del Consumo por Mes\n(Tendencia Temporal)', fontweight='bold', pad=20)
    ax1.set_xlabel('Mes', fontweight='bold')
    ax1.set_ylabel('Consumo (Millones)', fontweight='bold')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    ax1.set_xticks([9, 10])
    ax1.set_xticklabels(['Septiembre', 'Octubre'])
    
    # Panel 2: Comparativa Mensual
    ax2 = plt.subplot(2, 2, 2)
    
    sept_data = df_temporal[df_temporal['MES'] == 9]['Consumo_Total'].values
    oct_data = df_temporal[df_temporal['MES'] == 10]['Consumo_Total'].values
    depts = df_temporal[df_temporal['MES'] == 9]['DEPARTAMENTO'].values
    
    x = np.arange(len(depts))
    width = 0.35
    
    bars1 = ax2.bar(x - width/2, sept_data/1000000, width, label='Septiembre', color='#005A9B')
    bars2 = ax2.bar(x + width/2, oct_data/1000000, width, label='Octubre', color='#44AA99')
    
    ax2.set_title('📊 Comparativa Mensual\n(Septiembre vs Octubre)', fontweight='bold', pad=20)
    ax2.set_xlabel('Departamento', fontweight='bold')
    ax2.set_ylabel('Consumo (Millones)', fontweight='bold')
    ax2.set_xticks(x)
    ax2.set_xticklabels(depts, rotation=45)
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # Panel 3: Análisis de Clientes Activos
    ax3 = plt.subplot(2, 2, 3)
    
    for dept in df_temporal['DEPARTAMENTO'].unique():
        data_dept = df_temporal[df_temporal['DEPARTAMENTO'] == dept]
        ax3.plot(data_dept['MES'], data_dept['ID_CLIENTE']/1000, 
                marker='s', linewidth=3, markersize=8, label=dept)
    
    ax3.set_title('👥 Evolución Clientes Activos\n(Miles)', fontweight='bold', pad=20)
    ax3.set_xlabel('Mes', fontweight='bold')
    ax3.set_ylabel('Clientes Activos (Miles)', fontweight='bold')
    ax3.legend()
    ax3.grid(True, alpha=0.3)
    ax3.set_xticks([9, 10])
    ax3.set_xticklabels(['Septiembre', 'Octubre'])
    
    # Panel 4: Promedio de Consumo
    ax4 = plt.subplot(2, 2, 4)
    
    consumo_promedio_pivot = df_temporal.pivot_table(values='Consumo_Promedio', 
                                                    index='DEPARTAMENTO', 
                                                    columns='MES', 
                                                    aggfunc='mean')
    
    sns.heatmap(consumo_promedio_pivot, annot=True, fmt='.1f', 
                cmap='RdYlBu_r', ax=ax4, cbar_kws={'label': 'Consumo Promedio'})
    ax4.set_title('🌡️ Mapa de Calor - Consumo Promedio\n(Por Departamento y Mes)', 
                  fontweight='bold', pad=20)
    ax4.set_xlabel('Mes', fontweight='bold')
    ax4.set_ylabel('Departamento', fontweight='bold')
    
    plt.tight_layout()
    return fig

def crear_dashboard_top_consumidores(df_top):
    """
    Dashboard Nivel 3: Top Consumidores (Data Mart de Clientes VIP)
    """
    fig = plt.figure(figsize=(16, 10))
    fig.suptitle('🏆 DASHBOARD TOP CONSUMIDORES\n(Data Mart Clientes VIP - Análisis Detallado)', 
                 fontsize=16, fontweight='bold', y=0.95)
    
    # Panel 1: Ranking Top 10
    ax1 = plt.subplot(2, 2, 1)
    
    top_10 = df_top.head(10).sort_values('Consumo_Total', ascending=True)
    colors = plt.cm.plasma(np.linspace(0, 1, len(top_10)))
    
    bars = ax1.barh(range(len(top_10)), top_10['Consumo_Total']/1000, color=colors)
    ax1.set_yticks(range(len(top_10)))
    ax1.set_yticklabels([f'Cliente {id}' for id in top_10['ID_CLIENTE']])
    ax1.set_title('🥇 Top 10 Consumidores\n(Miles de unidades)', fontweight='bold', pad=20)
    ax1.set_xlabel('Consumo (Miles)', fontweight='bold')
    
    # Agregar valores en las barras
    for i, bar in enumerate(bars):
        width = bar.get_width()
        ax1.text(width + 10, bar.get_y() + bar.get_height()/2, 
                f'{width:.0f}K', ha='left', va='center', fontweight='bold')
    
    # Panel 2: Distribución por Departamento
    ax2 = plt.subplot(2, 2, 2)
    
    dept_counts = df_top['DEPARTAMENTO'].value_counts()
    colors_pie = ['#005A9B', '#44AA99', '#999933'][:len(dept_counts)]
    
    wedges, texts, autotexts = ax2.pie(dept_counts.values, 
                                       labels=dept_counts.index,
                                       autopct='%1.1f%%', 
                                       colors=colors_pie,
                                       startangle=90)
    
    ax2.set_title('🌍 Distribución Geográfica\n(Top Consumidores)', fontweight='bold', pad=20)
    
    # Panel 3: Análisis de Concentración
    ax3 = plt.subplot(2, 2, 3)
    
    df_top_sorted = df_top.sort_values('Consumo_Total', ascending=False)
    df_top_sorted['Consumo_Acumulado'] = df_top_sorted['Consumo_Total'].cumsum()
    df_top_sorted['Porcentaje_Acumulado'] = (df_top_sorted['Consumo_Acumulado'] / 
                                           df_top_sorted['Consumo_Total'].sum()) * 100
    
    ax3.plot(range(1, len(df_top_sorted)+1), df_top_sorted['Porcentaje_Acumulado'], 
             marker='o', linewidth=3, markersize=6, color='#005A9B')
    ax3.axhline(y=80, color='red', linestyle='--', alpha=0.7, label='Regla 80/20')
    
    ax3.set_title('📊 Curva de Concentración\n(Principio de Pareto)', fontweight='bold', pad=20)
    ax3.set_xlabel('Número de Clientes', fontweight='bold')
    ax3.set_ylabel('% Consumo Acumulado', fontweight='bold')
    ax3.grid(True, alpha=0.3)
    ax3.legend()
    
    # Panel 4: Métricas de Top Consumidores
    ax4 = plt.subplot(2, 2, 4)
    ax4.axis('off')
    
    # Calcular métricas
    consumo_max = df_top['Consumo_Total'].max()
    consumo_min = df_top['Consumo_Total'].min()
    consumo_promedio = df_top['Consumo_Total'].mean()
    diferencia = consumo_max - consumo_min
    
    metricas = [
        ('Consumo Máximo', f'{consumo_max/1000:.0f}K', '#FF6B6B'),
        ('Consumo Mínimo', f'{consumo_min/1000:.0f}K', '#4ECDC4'),
        ('Promedio Top 10', f'{consumo_promedio/1000:.0f}K', '#45B7D1'),
        ('Diferencia', f'{diferencia/1000:.0f}K', '#96CEB4')
    ]
    
    y_positions = [0.8, 0.6, 0.4, 0.2]
    
    for i, (label, value, color) in enumerate(metricas):
        # Crear rectángulo de fondo
        rect = Rectangle((0.1, y_positions[i]-0.06), 0.8, 0.12, 
                        facecolor=color, alpha=0.2)
        ax4.add_patch(rect)
        
        # Agregar texto
        ax4.text(0.5, y_positions[i]+0.01, value, 
                ha='center', va='center', fontsize=16, fontweight='bold', color=color)
        ax4.text(0.5, y_positions[i]-0.03, label, 
                ha='center', va='center', fontsize=10, fontweight='bold')
    
    ax4.set_xlim(0, 1)
    ax4.set_ylim(0, 1)
    ax4.set_title('📊 Métricas Clientes VIP\n(Indicadores Clave)', fontweight='bold', pad=20)
    
    plt.tight_layout()
    return fig

def crear_resumen_ejecutivo(df_cartera, df_distribucion, df_temporal, df_departamento):
    """
    Dashboard Ejecutivo: Vista de Alto Nivel para la Gerencia
    """
    fig = plt.figure(figsize=(20, 12))
    fig.suptitle('👔 RESUMEN EJECUTIVO - INTELIGENCIA DE NEGOCIOS\n(Metodología Bill Inmon - Data Warehouse Corporativo)', 
                 fontsize=18, fontweight='bold', y=0.95)
    
    # Configurar grid personalizado
    gs = fig.add_gridspec(3, 4, height_ratios=[1, 1.5, 1], width_ratios=[1, 1, 1, 1])
    
    # Fila superior: KPIs principales
    kpi_axes = [fig.add_subplot(gs[0, i]) for i in range(4)]
    
    # Calcular KPIs principales
    total_consumo = df_departamento['Consumo_Total_sum'].sum()
    total_clientes = df_departamento['ID_CLIENTE_nunique'].sum()
    crecimiento_oct = ((df_temporal[df_temporal['MES']==10]['Consumo_Total'].sum() - 
                       df_temporal[df_temporal['MES']==9]['Consumo_Total'].sum()) / 
                       df_temporal[df_temporal['MES']==9]['Consumo_Total'].sum()) * 100
    eficiencia = total_consumo / total_clientes
    
    kpis_data = [
        ('Consumo Total', f'{total_consumo/1000000:.1f}M', '#1f77b4'),
        ('Total Clientes', f'{total_clientes/1000:.0f}K', '#ff7f0e'),
        ('Crecimiento Oct', f'{crecimiento_oct:.1f}%', '#2ca02c'),
        ('Eficiencia', f'{eficiencia:.0f}', '#d62728')
    ]
    
    for i, (kpi_ax, (titulo, valor, color)) in enumerate(zip(kpi_axes, kpis_data)):
        kpi_ax.axis('off')
        
        # Crear círculo de fondo
        circle = plt.Circle((0.5, 0.5), 0.4, color=color, alpha=0.2)
        kpi_ax.add_patch(circle)
        
        # Agregar texto
        kpi_ax.text(0.5, 0.6, valor, ha='center', va='center', 
                   fontsize=20, fontweight='bold', color=color)
        kpi_ax.text(0.5, 0.3, titulo, ha='center', va='center', 
                   fontsize=12, fontweight='bold')
        kpi_ax.set_xlim(0, 1)
        kpi_ax.set_ylim(0, 1)
    
    # Fila central: Gráficos principales
    ax_mapa = fig.add_subplot(gs[1, :2])
    ax_evolucion = fig.add_subplot(gs[1, 2:])
    
    # Mapa de consumo por departamento y cartera
    consumo_pivot = df_cartera.pivot_table(values='Consumo_Total_sum', 
                                         index='DEPARTAMENTO', 
                                         columns='CARTERA', 
                                         aggfunc='sum')
    
    im = ax_mapa.imshow(consumo_pivot.values, cmap='Blues', aspect='auto')
    ax_mapa.set_xticks(range(len(consumo_pivot.columns)))
    ax_mapa.set_yticks(range(len(consumo_pivot.index)))
    ax_mapa.set_xticklabels(consumo_pivot.columns)
    ax_mapa.set_yticklabels(consumo_pivot.index)
    
    # Agregar valores en las celdas
    for i in range(len(consumo_pivot.index)):
        for j in range(len(consumo_pivot.columns)):
            value = consumo_pivot.iloc[i, j]
            ax_mapa.text(j, i, f'{value/1000000:.1f}M', 
                        ha='center', va='center', fontweight='bold', 
                        color='white' if value > consumo_pivot.values.max()/2 else 'black')
    
    ax_mapa.set_title('🗺️ Mapa Estratégico de Consumo\n(Millones por Departamento y Cartera)', 
                     fontweight='bold', pad=20)
    
    # Evolución temporal con proyección
    dept_colors = {'Ancash': '#1f77b4', 'Cajamarca': '#ff7f0e', 'La Libertad': '#2ca02c'}
    
    for dept in df_temporal['DEPARTAMENTO'].unique():
        data_dept = df_temporal[df_temporal['DEPARTAMENTO'] == dept]
        ax_evolucion.plot(data_dept['MES'], data_dept['Consumo_Total']/1000000, 
                         marker='o', linewidth=4, markersize=10, 
                         label=dept, color=dept_colors.get(dept, '#999999'))
        
        # Proyección simple para noviembre
        if len(data_dept) >= 2:
            tasa_crecimiento = (data_dept.iloc[-1]['Consumo_Total'] - 
                              data_dept.iloc[0]['Consumo_Total']) / data_dept.iloc[0]['Consumo_Total']
            proyeccion = data_dept.iloc[-1]['Consumo_Total'] * (1 + tasa_crecimiento)
            ax_evolucion.plot([10, 11], [data_dept.iloc[-1]['Consumo_Total']/1000000, 
                             proyeccion/1000000], 
                            '--', color=dept_colors.get(dept, '#999999'), alpha=0.7)
    
    ax_evolucion.set_title('📈 Evolución y Proyección de Consumo\n(Septiembre - Noviembre)', 
                          fontweight='bold', pad=20)
    ax_evolucion.set_xlabel('Mes', fontweight='bold')
    ax_evolucion.set_ylabel('Consumo (Millones)', fontweight='bold')
    ax_evolucion.set_xticks([9, 10, 11])
    ax_evolucion.set_xticklabels(['Sep', 'Oct', 'Nov (Proy)'])
    ax_evolucion.legend(loc='upper left')
    ax_evolucion.grid(True, alpha=0.3)
    
    # Fila inferior: Distribución y recomendaciones
    ax_dist = fig.add_subplot(gs[2, :2])
    ax_rec = fig.add_subplot(gs[2, 2:])
    
    # Distribución de consumidores con análisis de Pareto
    sorted_dist = df_distribucion.sort_values('count', ascending=False)
    colors_dist = ['#FF6B6B' if x == sorted_dist['count'].max() else '#4ECDC4' 
                   for x in sorted_dist['count']]
    
    bars = ax_dist.bar(sorted_dist['Rango_Consumo'], sorted_dist['count']/1000, 
                       color=colors_dist, alpha=0.8)
    ax_dist.set_title('📊 Segmentación de Consumidores\n(Miles de Clientes por Rango)', 
                     fontweight='bold', pad=20)
    ax_dist.set_xlabel('Rango de Consumo', fontweight='bold')
    ax_dist.set_ylabel('Número de Clientes (Miles)', fontweight='bold')
    ax_dist.tick_params(axis='x', rotation=45)
    
    # Agregar valores en las barras
    for bar in bars:
        height = bar.get_height()
        ax_dist.text(bar.get_x() + bar.get_width()/2., height + 5,
                    f'{height:.0f}K', ha='center', va='bottom', fontweight='bold')
    
    # Panel de recomendaciones estratégicas
    ax_rec.axis('off')
    
    recomendaciones = [
        "🎯 RECOMENDACIONES ESTRATÉGICAS",
        "",
        "1. Enfoque en La Libertad (mayor consumo)",
        "2. Potenciar segmento MAYOR en Ancash", 
        "3. Retener clientes de rango 101-500",
        "4. Investigar caída en Cajamarca (Oct)",
        "5. Implementar programa VIP para top consumers",
        "",
        "📈 OPORTUNIDADES DE CRECIMIENTO:",
        "• Expansión en mercado COMÚN",
        "• Cross-selling a clientes MAYOR", 
        "• Fidelización segmento medio (51-100)"
    ]
    
    y_start = 0.95
    for i, rec in enumerate(recomendaciones):
        if rec.startswith("🎯"):
            ax_rec.text(0.05, y_start - i*0.07, rec, fontsize=14, fontweight='bold', 
                       color='#2E86AB', transform=ax_rec.transAxes)
        elif rec.startswith("📈"):
            ax_rec.text(0.05, y_start - i*0.07, rec, fontsize=12, fontweight='bold', 
                       color='#A23B72', transform=ax_rec.transAxes)
        elif rec.startswith(("•", "1.", "2.", "3.", "4.", "5.")):
            ax_rec.text(0.1, y_start - i*0.07, rec, fontsize=10, 
                       color='#F18F01', transform=ax_rec.transAxes)
        else:
            ax_rec.text(0.05, y_start - i*0.07, rec, fontsize=10, 
                       transform=ax_rec.transAxes)
    
    ax_rec.set_xlim(0, 1)
    ax_rec.set_ylim(0, 1)
    
    plt.tight_layout()
    return fig

def main():
    """
    Función principal que ejecuta todos los dashboards siguiendo metodología Inmon
    """
    print("🚀 Iniciando creación de dashboards Power BI...")
    print("📊 Metodología: Bill Inmon (Top-Down Data Warehouse)")
    
    # Crear datos desde la información proporcionada
    df_cartera, df_distribucion, df_temporal, df_departamento, df_top = crear_datos_desde_texto()
    
    # Crear dashboards siguiendo metodología Top-Down
    print("\n📋 Creando Dashboard Nivel 1: Vista Corporativa...")
    fig1 = crear_dashboard_corporativo(df_cartera, df_departamento, df_distribucion)
    fig1.savefig('Dashboard_01_Corporativo.png', dpi=300, bbox_inches='tight')
    
    print("📋 Creando Dashboard Nivel 2: Análisis Temporal...")
    fig2 = crear_dashboard_temporal(df_temporal)
    fig2.savefig('Dashboard_02_Temporal.png', dpi=300, bbox_inches='tight')
    
    print("📋 Creando Dashboard Nivel 3: Top Consumidores...")
    fig3 = crear_dashboard_top_consumidores(df_top)
    fig3.savefig('Dashboard_03_TopConsumidores.png', dpi=300, bbox_inches='tight')
    
    print("📋 Creando Dashboard Ejecutivo: Resumen Gerencial...")
    fig4 = crear_resumen_ejecutivo(df_cartera, df_distribucion, df_temporal, df_departamento)
    fig4.savefig('Dashboard_04_Ejecutivo.png', dpi=300, bbox_inches='tight')
    
    plt.show()
    
    # Generar explicaciones detalladas
    generar_explicaciones_dashboards()

def generar_explicaciones_dashboards():
    """
    Genera explicaciones detalladas de cada gráfico siguiendo metodología Inmon
    """
    
    explicaciones = """
    
🏢 EXPLICACIÓN DE DASHBOARDS - METODOLOGÍA BILL INMON
================================================================

📊 DASHBOARD 1: VISTA CORPORATIVA (Data Warehouse Central)
----------------------------------------------------------

🔹 GRÁFICO 1 - Mapa de Calor Departamento/Cartera:
   • QUÉ ES: Matriz que cruza ubicación geográfica con tipo de cartera
   • INSIGHTS: La Libertad domina en ambas carteras, Ancash fuerte en MAYOR
   • USO BI: Identifica mercados estratégicos y oportunidades de expansión

🔹 GRÁFICO 2 - Distribución por Rangos de Consumo:
   • QUÉ ES: Segmentación de clientes según nivel de consumo
   • INSIGHTS: 212K clientes en rango medio-alto (101-500), gran oportunidad
   • USO BI: Estrategias de precios y campañas diferenciadas por segmento

🔹 GRÁFICO 3 - Consumo Total por Departamento:
   • QUÉ ES: Ranking de departamentos por volumen total de consumo
   • INSIGHTS: La Libertad lidera con 66.4M, seguido por Ancash (34.8M)
   • USO BI: Asignación de recursos y priorización de inversiones

🔹 GRÁFICO 4 - Análisis por Cartera:
   • QUÉ ES: Comparativa entre carteras COMÚN y MAYOR
   • INSIGHTS: COMÚN tiene más volumen pero MAYOR es más rentable per cápita
   • USO BI: Estrategias diferenciadas de retención y up-selling

🔹 GRÁFICO 5 - KPIs Corporativos:
   • QUÉ ES: Indicadores clave consolidados del Data Warehouse
   • INSIGHTS: 113.3M consumo total, 946K clientes, promedio 61.7
   • USO BI: Monitoreo ejecutivo y benchmarking

🔹 GRÁFICO 6 - Matriz de Eficiencia:
   • QUÉ ES: Relación entre número de clientes y consumo total
   • INSIGHTS: La Libertad es el mercado más eficiente y grande
   • USO BI: Optimización de portfolio y estrategia de mercado

================================================================

📅 DASHBOARD 2: ANÁLISIS TEMPORAL (Data Mart Temporal)
------------------------------------------------------

🔹 GRÁFICO 1 - Evolución Mensual:
   • QUÉ ES: Tendencia de consumo septiembre vs octubre por departamento
   • INSIGHTS: Fuerte caída en todos los departamentos en octubre
   • USO BI: Planificación estacional y ajuste de forecasting

🔹 GRÁFICO 2 - Comparativa Mensual:
   • QUÉ ES: Barras comparativas entre los dos meses analizados
   • INSIGHTS: La Libertad mantiene liderazgo pero con reducción significativa
   • USO BI: Análisis de variaciones y investigación de causas

🔹 GRÁFICO 3 - Clientes Activos:
   • QUÉ ES: Evolución del número de clientes que consumieron por mes
   • INSIGHTS: Reducción drástica de clientes activos en octubre
   • USO BI: Estrategias de reactivación y retención de clientes

🔹 GRÁFICO 4 - Mapa de Calor Consumo Promedio:
   • QUÉ ES: Consumo promedio por cliente según mes y departamento
   • INSIGHTS: Aumentos significativos en consumo promedio en octubre
   • USO BI: Detección de cambios en patrones de comportamiento

================================================================

🏆 DASHBOARD 3: TOP CONSUMIDORES (Data Mart Clientes VIP)
---------------------------------------------------------

🔹 GRÁFICO 1 - Ranking Top 10:
   • QUÉ ES: Los 10 clientes con mayor consumo individual
   • INSIGHTS: Cliente 313664 consume 1.36M, brecha enorme con el resto
   • USO BI: Programas VIP personalizados y gestión de cuentas clave

🔹 GRÁFICO 2 - Distribución Geográfica VIP:
   • QUÉ ES: Ubicación de los top consumidores por departamento
   • INSIGHTS: Top consumers se concentran principalmente en Ancash
   • USO BI: Estrategias territoriales y gestión comercial regional

🔹 GRÁFICO 3 - Curva de Concentración (Pareto):
   • QUÉ ES: Análisis de concentración del consumo en pocos clientes
   • INSIGHTS: Alto grado de concentración, pocos clientes generan mucho valor
   • USO BI: Focalización de esfuerzos en clientes de alto valor

🔹 GRÁFICO 4 - Métricas VIP:
   • QUÉ ES: Indicadores clave del segmento de top consumidores
   • INSIGHTS: Gran variabilidad en consumos, oportunidad de segmentación
   • USO BI: Definición de niveles VIP y beneficios diferenciados

================================================================

👔 DASHBOARD 4: RESUMEN EJECUTIVO (Vista Gerencial)
--------------------------------------------------

🔹 KPIs PRINCIPALES:
   • Consumo Total: 113.3M - Volumen total de negocio
   • Total Clientes: 946K - Base de clientes activos
   • Crecimiento Oct: -38.8% - Alerta de reducción significativa
   • Eficiencia: 120 - Consumo promedio por cliente

🔹 MAPA ESTRATÉGICO:
   • QUÉ ES: Visualización integrada de todos los segmentos de mercado
   • INSIGHTS: La Libertad COMÚN es el segmento más grande (47.6M)
   • USO BI: Planificación estratégica y asignación de recursos

🔹 EVOLUCIÓN Y PROYECCIÓN:
   • QUÉ ES: Tendencia histórica con proyección a noviembre
   • INSIGHTS: Si continúa la tendencia, habrá recuperación parcial
   • USO BI: Forecasting y planificación operativa

🔹 RECOMENDACIONES ESTRATÉGICAS:
   • Enfoque prioritario en La Libertad (mayor mercado)
   • Desarrollo de segmento MAYOR en Ancash (oportunidad)
   • Retención de clientes rango 101-500 (segmento clave)
   • Investigación de caída en octubre (acción inmediata)
   • Programa VIP para top consumers (fidelización)

================================================================

🎯 METODOLOGÍA BILL INMON APLICADA:
----------------------------------

1. DATA WAREHOUSE CORPORATIVO: Dashboard 1 integra toda la información
2. DATA MARTS ESPECIALIZADOS: Dashboards 2 y 3 derivan del DW principal  
3. VISTA EJECUTIVA: Dashboard 4 consolida insights para toma de decisiones
4. ENFOQUE TOP-DOWN: Desde lo general (corporativo) a lo específico (VIP)
5. FUENTE ÚNICA DE VERDAD: Todos los datos vienen del mismo DW integrado

Esta estructura permite análisis coherentes y toma de decisiones informada
en todos los niveles organizacionales, desde operativo hasta estratégico.

================================================================
    """
    
    print(explicaciones)

# Ejecutar el programa principal
if __name__ == "__main__":
    main()